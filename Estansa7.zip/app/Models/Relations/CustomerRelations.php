<?php

namespace App\Models\Relations;

trait CustomerRelations
{
    //
}
