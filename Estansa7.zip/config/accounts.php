<?php

return [

    /*
     * The firebase project id for password less authentication.
     */
    'firebase_project_id' => env('FIREBASE_PROJECT_ID'),
];
