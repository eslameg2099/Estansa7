<?php

return [
    /*
     * The layout of dashboard.
     *
     * Supported : "vali", "adminlte3"
     */
    'dashboard' => 'adminlte3',

    /*
     * The layout of front end.
     *
     * Supported : "vali", "adminlte3"
     */
    'frontend' => 'adminlte3',
];
