@extends('dashboard::auth.passwords.confirm')
