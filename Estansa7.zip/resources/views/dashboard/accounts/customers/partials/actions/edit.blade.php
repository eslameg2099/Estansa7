@can('update', $customer)
    <a href="{{ route('dashboard.customers.edit', $customer) }}" class="btn btn-outline-primary btn-sm">
        <i class="fas fa fa-fw fa-user-edit"></i>
    </a>
@endcan
