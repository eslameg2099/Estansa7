@can('update', $supervisor)
    <a href="{{ route('dashboard.supervisors.edit', $supervisor) }}" class="btn btn-outline-primary btn-sm">
        <i class="fas fa fa-fw fa-user-edit"></i>
    </a>
@endcan
