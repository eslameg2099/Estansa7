<span class="badge badge-success">{{ $supervisor->present()->type }}</span>
