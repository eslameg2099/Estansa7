@can('update', $admin)
    <a href="{{ route('dashboard.admins.edit', $admin) }}" class="btn btn-outline-primary btn-sm">
        <i class="fas fa fa-fw fa-user-edit"></i>
    </a>
@endcan
