@include('dashboard.errors')

{{ BsForm::text('name') }}

