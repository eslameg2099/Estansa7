    <a href="{{ route('dashboard.categorypost.create') }}" class="btn btn-outline-success btn-sm">
        <i class="fas fa fa-fw fa-plus"></i>
        اضافة
    </a>
