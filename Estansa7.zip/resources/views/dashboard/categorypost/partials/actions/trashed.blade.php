    <a href="{{ route('dashboard.categoryprovider.trashed') }}" class="btn btn-outline-danger btn-sm">
        <i class="fas fa fa-fw fa-trash"></i>
        @lang('categoryprovider.trashed')
    </a>

