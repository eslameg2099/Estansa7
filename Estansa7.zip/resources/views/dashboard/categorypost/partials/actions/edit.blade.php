    <a href="{{ route('dashboard.categorypost.edit', $categorypost->id) }}" class="btn btn-outline-primary btn-sm">
        <i class="fas fa fa-fw fa-edit"></i>
    </a>
