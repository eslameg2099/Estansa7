    <a href="{{ route('dashboard.categoryprovider.edit', $categoryprovider->id) }}" class="btn btn-outline-primary btn-sm">
        <i class="fas fa fa-fw fa-edit"></i>
    </a>
