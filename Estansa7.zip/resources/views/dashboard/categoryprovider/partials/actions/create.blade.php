    <a href="{{ route('dashboard.categoryprovider.create') }}" class="btn btn-outline-success btn-sm">
        <i class="fas fa fa-fw fa-plus"></i>
        اضافة
    </a>
