<?php

return [
    'plural' => 'Permissions',
    'manage.supervisors' => 'Manage Supervisors',
    'manage.customers' => 'Manage Customers',
    'manage.feedback' => 'Manage Feedback',
    'manage.settings' => 'Manage Settings',
];
