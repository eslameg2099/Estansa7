<?php

return [
    'singular' => 'Notification',
    'plural' => 'Notifications',
    'empty' => 'There are no notifications yet.',
    'new-feedback' => 'New feedback message',
    'new-customer' => ':user has been create a new account',
];
