<?php

return [
    'download' => 'Download Database',
    'not-found' => 'There are no backups!',
];
