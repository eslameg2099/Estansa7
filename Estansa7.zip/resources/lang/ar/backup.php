<?php

return [
    'download' => 'تحميل قاعدة البيانات',
    'not-found' => 'لا يوجد نسخة احتياطية',
];
