<?php

return [
    'singular' => 'الاشعار',
    'plural' => 'الاشعارات',
    'empty' => 'لا يوجد اشعارات حتى الان',
    'new-feedback' => 'رسالة جديدة من صفحة اتصل بنا',
    'new-customer' => 'قام :user بإنشاء حساب جديد',
];
