<?php

return [
    'plural' => 'الصلاحيات',
];
